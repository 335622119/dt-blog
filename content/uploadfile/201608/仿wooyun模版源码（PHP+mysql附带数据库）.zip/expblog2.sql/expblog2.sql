-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2011 年 05 月 01 日 10:17
-- 服务器版本: 5.5.8
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `expblog2`
--

-- --------------------------------------------------------

--
-- 表的结构 `exp_admins`
--

CREATE TABLE IF NOT EXISTS `exp_admins` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `exp_username` varchar(50) NOT NULL,
  `exp_password` varchar(100) NOT NULL,
  `exp_status` tinyint(2) DEFAULT NULL,
  `exp_email` varchar(50) DEFAULT NULL,
  `exp_regtime` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `exp_admins`
--

INSERT INTO `exp_admins` (`id`, `exp_username`, `exp_password`, `exp_status`, `exp_email`, `exp_regtime`) VALUES
(1, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 0, 'admin@gmail.com', '2011-04-27');

-- --------------------------------------------------------

--
-- 表的结构 `exp_category`
--

CREATE TABLE IF NOT EXISTS `exp_category` (
  `exp_category_id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '分类ID',
  `exp_bugtype` varchar(50) DEFAULT NULL COMMENT '分类名',
  `exp_category_fid` int(11) DEFAULT NULL COMMENT '分类父ID',
  `exp_corptype` int(2) DEFAULT NULL COMMENT '问题厂商类型',
  PRIMARY KEY (`exp_category_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=46 ;

--
-- 转存表中的数据 `exp_category`
--

INSERT INTO `exp_category` (`exp_category_id`, `exp_bugtype`, `exp_category_fid`, `exp_corptype`) VALUES
(1, '网络边界/基础架构', 0, 1),
(2, '网络设计缺陷/逻辑错误', 1, 1),
(3, '基础设施弱口令', 1, 1),
(4, '网络未授权访问', 1, 1),
(5, '网络敏感信息泄漏', 1, 1),
(6, '系统运维/服务设置', 0, 1),
(7, '系统/服务补丁不及时', 6, 1),
(8, '重要敏感信息泄露', 6, 1),
(9, '未授权访问/权限绕过', 6, 1),
(10, '服务弱口令', 6, 1),
(11, '系统/服务运维配置不当', 6, 1),
(12, '应用程序/应用漏洞', 0, 1),
(13, 'xss跨站脚本攻击', 12, 1),
(14, 'CSRF', 12, 1),
(15, 'SQL注射漏洞', 12, 1),
(16, '任意文件遍历/下载', 12, 1),
(17, '文件上传导致任意代码执行', 12, 1),
(18, '文件包含', 12, 1),
(19, '命令执行', 12, 1),
(20, '应用配置错误', 12, 1),
(21, '敏感信息泄露', 12, 1),
(22, '未授权访问/权限绕过', 12, 1),
(23, '后台弱口令', 12, 1),
(24, '设计缺陷/逻辑错误', 12, 1),
(25, 'URL跳转', 12, 1),
(26, '业务安全/运营风险', 0, 1),
(27, '钓鱼欺诈信息', 26, 1),
(28, '账户体系控制不严', 26, 1),
(29, '内容安全', 26, 1),
(30, '恶意信息传播', 26, 1),
(31, '安全事件/安全情报', 0, 1),
(32, '内部绝密信息泄漏', 31, 1),
(33, '用户资料大量泄漏', 31, 1),
(34, '成功的入侵事件', 31, 1),
(35, '网络设备/硬件设施232', 0, 2),
(36, '设计不当', 35, 2),
(37, '非授权访问', 35, 2),
(38, '权限控制绕过', 35, 2),
(39, '默认配置不当', 35, 2),
(40, 'fdsafasd', 39, 2),
(43, '业务安全/运营风', 26, 1),
(44, '应用程序/应用漏洞123', 12, 1);

-- --------------------------------------------------------

--
-- 表的结构 `exp_code`
--

CREATE TABLE IF NOT EXISTS `exp_code` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `exp_code` varchar(50) NOT NULL COMMENT '邀请码',
  `exp_isused` int(1) NOT NULL COMMENT '是否被使用',
  `codetime` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- 转存表中的数据 `exp_code`
--

INSERT INTO `exp_code` (`id`, `exp_code`, `exp_isused`, `codetime`) VALUES
(14, 'YbkIrhlCi13', 0, '2011-04-30 13:44:11'),
(2, '456789', 0, '0000-00-00 00:00:00'),
(3, 'vcYIDpNeM2', 0, '2011-04-30 04:11:38'),
(4, 'aHQpWqDKE3', 1, '2011-04-30 04:11:38'),
(5, 'TwqMWsDAE4', 0, '2011-04-30 04:11:38'),
(6, 'yNzIjCRQs5', 0, '2011-04-30 04:11:38'),
(7, 'DcTNknMlI6', 0, '2011-04-30 04:11:38'),
(8, 'nlrdXcsgh7', 0, '2011-04-30 04:14:57'),
(9, 'zfDFHvAVi8', 0, '2011-04-30 04:14:57'),
(10, 'wzVnFqoOW9', 0, '2011-04-30 04:14:57'),
(11, 'zfkiFJIpS10', 0, '2011-04-30 04:14:57'),
(12, 'FLKnNwcsT11', 0, '2011-04-30 04:14:57'),
(13, 'ksbJmCOdG12', 0, '2011-04-30 11:37:10'),
(15, 'ksvPeDbnM14', 0, '2011-04-30 13:44:11'),
(16, 'HvjCwgyRa15', 0, '2011-04-30 13:44:11');

-- --------------------------------------------------------

--
-- 表的结构 `exp_corps`
--

CREATE TABLE IF NOT EXISTS `exp_corps` (
  `corps_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `exp_corpser` varchar(50) NOT NULL DEFAULT '' COMMENT '厂商名',
  `exp_homepage` varchar(50) DEFAULT NULL COMMENT '厂商主页',
  `exp_doing` varchar(200) DEFAULT NULL COMMENT '厂商活动',
  `exp_addtime` date DEFAULT NULL COMMENT '添加时间',
  `exp_corps_intro` varchar(200) DEFAULT NULL,
  `exp_username` varchar(50) NOT NULL COMMENT '厂商用户名',
  `exp_email` varchar(50) DEFAULT NULL COMMENT '厂商电子邮件',
  `exp_password` varchar(100) DEFAULT NULL COMMENT '厂商密码',
  `exp_status` int(1) DEFAULT NULL,
  `corps_mobile` varchar(20) DEFAULT NULL COMMENT '厂商手机',
  `corps_telephone` varchar(20) DEFAULT NULL COMMENT '厂商电话',
  PRIMARY KEY (`corps_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `exp_corps`
--

INSERT INTO `exp_corps` (`corps_id`, `exp_corpser`, `exp_homepage`, `exp_doing`, `exp_addtime`, `exp_corps_intro`, `exp_username`, `exp_email`, `exp_password`, `exp_status`, `corps_mobile`, `corps_telephone`) VALUES
(1, '腾讯', 'http://www.tencent.com', NULL, '2011-04-27', '腾讯公司成立于1998年11月，是目前中国最大的互联网综合服务提供商之一，也是中国服务用户最多的互联网企业之一。目前该帐号由腾讯安全应急响应中心（TSRC，Tencent Security Response Center）维护，我们非常认同wooyun的运营模式，当然也欢迎直接向我们报告安全问题security@tencent.co', '', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `exp_menu`
--

CREATE TABLE IF NOT EXISTS `exp_menu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `exp_menu_name` varchar(50) NOT NULL,
  `exp_menu_title` varchar(100) DEFAULT NULL,
  `exp_menu_sort` int(11) DEFAULT NULL,
  `exp_menu_fid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `exp_menu`
--


-- --------------------------------------------------------

--
-- 表的结构 `exp_offer`
--

CREATE TABLE IF NOT EXISTS `exp_offer` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `offer_title` varchar(80) NOT NULL COMMENT '招聘标题',
  `offer_category_id` int(11) NOT NULL COMMENT '公司城市分类',
  `offer_postime` date NOT NULL COMMENT '发布时间',
  `offer_text` text COMMENT '招聘内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `exp_offer`
--


-- --------------------------------------------------------

--
-- 表的结构 `exp_offer_category`
--

CREATE TABLE IF NOT EXISTS `exp_offer_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `exp_company` varchar(50) DEFAULT NULL COMMENT '公司',
  `exp_city` varchar(50) DEFAULT NULL COMMENT '城市',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `exp_offer_category`
--


-- --------------------------------------------------------

--
-- 表的结构 `exp_postcomments`
--

CREATE TABLE IF NOT EXISTS `exp_postcomments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `posts_id` int(11) NOT NULL COMMENT '文章ID',
  `user_id` int(11) NOT NULL COMMENT '用户ID',
  `content` text COMMENT '评论内容',
  `addtime` datetime DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `exp_postcomments`
--


-- --------------------------------------------------------

--
-- 表的结构 `exp_posts`
--

CREATE TABLE IF NOT EXISTS `exp_posts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `exp_post_no` varchar(50) NOT NULL DEFAULT '' COMMENT '缺陷编号',
  `exp_post_title` varchar(100) NOT NULL DEFAULT '' COMMENT '漏洞标题',
  `exp_post_producter` varchar(50) NOT NULL DEFAULT '' COMMENT '相关厂商',
  `exp_author_id` int(11) unsigned NOT NULL COMMENT '漏洞作者',
  `exp_post_time` date NOT NULL COMMENT '提交时间',
  `exp_pub_time` date NOT NULL COMMENT '公开时间',
  `exp_hazard_rating` int(1) NOT NULL COMMENT '危害等级',
  `exp_exploit_rank` int(1) NOT NULL COMMENT '自评Rank',
  `exp_exploit_status` int(1) NOT NULL DEFAULT '0' COMMENT '漏洞状态',
  `exp_exploit_from` varchar(50) NOT NULL COMMENT '漏洞来源',
  `exp_description` varchar(50) NOT NULL DEFAULT '' COMMENT '简要描述',
  `exp_content` text COMMENT '详细说明',
  `exp_exploit_fix` text COMMENT '修复方案',
  `exp_corptype` int(10) unsigned NOT NULL COMMENT '问题厂商类型',
  `exp_bugtype` int(10) unsigned DEFAULT NULL COMMENT '漏洞类型',
  `exp_content1` text COMMENT '漏洞证明',
  `exp_email` varchar(50) DEFAULT NULL COMMENT '电子邮箱',
  `exp_replay` text COMMENT '厂商回应',
  `exp_ispub` int(1) NOT NULL DEFAULT '0' COMMENT '漏洞是否公开',
  `is_confrim` int(1) NOT NULL DEFAULT '0' COMMENT '默认0需要审核',
  `other_bugtype` varchar(50) DEFAULT NULL COMMENT '其它漏洞类型',
  `other_corpname` varchar(50) DEFAULT NULL COMMENT '其它厂商',
  `posts_confrim` int(1) DEFAULT '0' COMMENT '审核是否显示',
  PRIMARY KEY (`id`),
  KEY `FK_exp_posts_1` (`exp_author_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `exp_posts`
--

INSERT INTO `exp_posts` (`id`, `exp_post_no`, `exp_post_title`, `exp_post_producter`, `exp_author_id`, `exp_post_time`, `exp_pub_time`, `exp_hazard_rating`, `exp_exploit_rank`, `exp_exploit_status`, `exp_exploit_from`, `exp_description`, `exp_content`, `exp_exploit_fix`, `exp_corptype`, `exp_bugtype`, `exp_content1`, `exp_email`, `exp_replay`, `exp_ispub`, `is_confrim`, `other_bugtype`, `other_corpname`, `posts_confrim`) VALUES
(9, '20110430', 'TX被黑啦', '1', 1, '2011-04-30', '0000-00-00', 3, 134, 3, '', 'TX被黑啦', 'TX被黑啦', 'TX被黑啦', 1, 7, 'TX被黑啦', 'mr.zxing@gmail.com', NULL, 0, 0, NULL, NULL, 0),
(10, '20110501', 'fdsafdsa', '1', 1, '2011-05-01', '0000-00-00', 2, 6, 0, '', 'fdsafdsafdsa', 'fdsafsadfdsa', 'fdsafdsagfds', 1, 9, 'fdsafsad', '', NULL, 0, 0, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- 表的结构 `exp_system`
--

CREATE TABLE IF NOT EXISTS `exp_system` (
  `exp_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `is_reg` int(2) DEFAULT '1' COMMENT '是否允许注册',
  PRIMARY KEY (`exp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 转存表中的数据 `exp_system`
--


-- --------------------------------------------------------

--
-- 表的结构 `exp_users`
--

CREATE TABLE IF NOT EXISTS `exp_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `exp_username` varchar(50) NOT NULL,
  `exp_password` varchar(50) NOT NULL,
  `exp_regtime` date DEFAULT NULL,
  `exp_ip` char(11) DEFAULT NULL,
  `exp_status` int(1) DEFAULT NULL,
  `exp_homepage` varchar(50) DEFAULT NULL,
  `exp_useremail` varchar(50) NOT NULL,
  `exp_userprofile` varchar(100) DEFAULT NULL,
  `exp_truename` varchar(20) DEFAULT NULL,
  `exp_mobile` varchar(20) DEFAULT NULL,
  `exp_telephone` varchar(20) DEFAULT NULL,
  `exp_useraddress` varchar(200) DEFAULT NULL,
  `exp_postalcode` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `exp_username` (`exp_username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `exp_users`
--

INSERT INTO `exp_users` (`id`, `exp_username`, `exp_password`, `exp_regtime`, `exp_ip`, `exp_status`, `exp_homepage`, `exp_useremail`, `exp_userprofile`, `exp_truename`, `exp_mobile`, `exp_telephone`, `exp_useraddress`, `exp_postalcode`) VALUES
(1, '路人甲', 'e10adc3949ba59abbe56e057f20f883e', '2012-00-00', '127.0.0.1', 2, 'www.baidu.com', 'user@gmail.com', 'homepage12', '张三', '13229122810', '4656123', '我的地址', '441400');

--
-- 限制导出的表
--

--
-- 限制表 `exp_offer_category`
--
ALTER TABLE `exp_offer_category`
  ADD CONSTRAINT `FK_exp_offer_category` FOREIGN KEY (`id`) REFERENCES `exp_offer` (`id`);
