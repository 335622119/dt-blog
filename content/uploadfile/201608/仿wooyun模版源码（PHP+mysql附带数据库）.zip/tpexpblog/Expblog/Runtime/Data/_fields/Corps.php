<?php
return array (
  0 => 'corps_id',
  1 => 'exp_corpser',
  2 => 'exp_homepage',
  3 => 'exp_doing',
  4 => 'exp_addtime',
  5 => 'exp_corps_intro',
  6 => 'exp_username',
  7 => 'exp_email',
  8 => 'exp_password',
  9 => 'exp_status',
  10 => 'corps_mobile',
  11 => 'corps_telephone',
  '_autoinc' => true,
  '_pk' => 'corps_id',
);
?>