<?php
return array (
  0 => 'id',
  1 => 'exp_post_no',
  2 => 'exp_post_title',
  3 => 'exp_post_producter',
  4 => 'exp_author_id',
  5 => 'exp_post_time',
  6 => 'exp_pub_time',
  7 => 'exp_hazard_rating',
  8 => 'exp_exploit_rank',
  9 => 'exp_exploit_status',
  10 => 'exp_exploit_from',
  11 => 'exp_description',
  12 => 'exp_content',
  13 => 'exp_exploit_fix',
  14 => 'exp_corptype',
  15 => 'exp_bugtype',
  16 => 'exp_content1',
  17 => 'exp_email',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>