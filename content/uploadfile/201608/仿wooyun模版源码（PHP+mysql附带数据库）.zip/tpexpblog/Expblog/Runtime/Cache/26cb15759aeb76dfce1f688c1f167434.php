<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<!-- saved from url=(0031)index.php -->
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>0x255.com | 自由平等的漏洞报告平台</TITLE>
<META content="text/html; charset=utf-8" http-equiv=Content-Type>
<META name=author content=80sec>
<META name=copyright content=>
<META name=keywords content=,0x255,应用安全,web安全,系统安全,网络安全,漏洞公布,漏洞报告,安全资讯。>
<META name=description content=0x255是一个位于厂商和安全研究者之间的漏洞报告平台,注重尊重,进步,与意义><LINK 
title="wooyun.org 最新提交漏洞" rel=alternate type=application/rss+xml 
href=" feeds/submit"><LINK title="0x255.com 最新确认漏洞" 
rel=alternate type=application/rss+xml 
href=" feeds/confirm"><LINK title="0x255.com 最新公开漏洞" 
rel=alternate type=application/rss+xml 
href=" feeds/public"><LINK rel=stylesheet type=text/css 
href="__PUBLIC__/blog/css/style.css">
<SCRIPT type=text/javascript 
src="__PUBLIC__/blog/js/jquery-1.4.2.min.js"></SCRIPT>
<style>
.footerstyle TD A{color:#AB8D13}
.footerstyle TD A:visited {COLOR: #white; TEXT-DECORATION: none}
.footerstyle TD A:hover {COLOR: #white;}

</style>

<META name=GENERATOR content="MSHTML 8.00.6001.19046"></HEAD>
<BODY>
<DIV class=banner>
<TABLE border=0 cellSpacing=0 cellPadding=0 width="100%" bgColor=#ffffff 
align=center height=189>
  <TBODY>
  <TR>
    <TD height=5 background=__PUBLIC__/blog/images/bg4.jpg></TD></TR>
 
    <TD>
      <TABLE border=0 cellSpacing=0 cellPadding=0 width="100%" height=189>
        <TBODY>
        <TR>
          <TD height=189 background=__PUBLIC__/blog/images/globe.gif rowSpan=3 width=181 
          noWrap>&nbsp;</TD>
          <TD bgColor=#ffffff height=72 colSpan=2 noWrap>&nbsp;</TD>
          <TD bgColor=#ffffff height=72></TD></TR>
        <TR>
          <TD bgColor=#ffffff height=69 width=23 noWrap>&nbsp;</TD>
          <TD height=69><A href="http://www.0x255.com/"><IMG border=0 
            src="__PUBLIC__/blog/images/shell-storm.gif" height=69></A></TD>
          <TD bgColor=#ffffff height=69 align=right>&nbsp; <A 
            href="http://twitter.com/shell_storm"></A> </TD></TR>
        <TR>
          <TD height=48 background=__PUBLIC__/blog/images/milieu.gif width=23 
          noWrap>&nbsp;</TD>
          <TD height=48 background=__PUBLIC__/blog/images/milieu.gif colSpan=2 noWrap 
          align=left>&nbsp; <B><A href="__ROOT__/index" 
            target=_self>首页</A> |</B> <B><A 
            href="__ROOT__/Corps" target=_self>厂商列表</A> 
            |</B> <B><A href="__ROOT__/Whitehats" 
            target=_self>白帽子</A> |</B> <B><A 
            href="__ROOT__/bugs" target=_self>漏洞列表</A> 
            |</B> <B><A href="__ROOT__/bugsub" 
            target=_self>提交漏洞</A> |</B>   | 
            <?php if(isset($_SESSION['username'])): ?><B>&nbsp;&nbsp;欢迎<A 
            href="__ROOT__/Member/memberinfo" target=_self><?php echo ($_SESSION['username']); ?></A>白帽 <a href="__ROOT__/Member">控制面板</a>| <a href="__ROOT__/Member/loginout" class="reg">退出</a>  |</B> 
            <?php else: ?>
            <B><A 
            href="__ROOT__/Whitehats/userlogin" target=_self>白帽登陆</A> |</B>
           
            |<B><?php endif; ?>
                       <?php if(isset($_SESSION['corps_id'])): ?><B>&nbsp;&nbsp;欢迎<A 
            href="__ROOT__/Managecorps/corpsinfo" target=_self><?php echo ($_SESSION['exp_corpser']); ?></A>厂商<a href="__ROOT__/Managecorps">控制面板</a>| <a href="__ROOT__/Managecorps/loginout" class="reg">退出</a>  |</B> 
            <?php else: ?>
            <B><A 
            href="__ROOT__/Corps/corpslogin" target=_self>厂商登陆</A> |</B><?php endif; ?>

              </TD></TR></TBODY></TABLE>
 
	<div class="content" align="center">
		<div class="success" align="center">
			<p><?php echo ($message); ?></p>
			<p><a href="__ROOT__/<?php echo ($jumpUrl); ?>">如果长时间没有跳转，请点击这里</a></p>
		</div>
	</div>
 
		<br/>
     <TABLE border=0 cellSpacing=0 cellPadding=0  width="100%" 
      background=__PUBLIC__/blog/images/bg4.jpg class="footerstyle">
        <TBODY>
        <TR>
          <TD>&nbsp;<FONT color=#ffffff size=2><B><U>Links 
          :</B></FONT></U><BR></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<FONT color=#ffffff size=2><B><U>Others DNS 
            :</B></FONT></U><BR></TD>
          <TD>&nbsp;</TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="#" target=_blank><B>Nuit 
            Du Hack</B></A></TD>
          <TD>&nbsp;<A href="http://www.sysdream.com/" 
            target=_blank><B>Sysdream</B></A></TD>
          <TD>&nbsp;<A href="http://www.zeroscience.mk/" 
            target=_blank><B>ZeroScience</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://opensource.homeunix.com/"><B>DNS 
          1</B></A></TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://www.acissi.net/" 
            target=_blank><B>Acissi</B></A></TD>
          <TD>&nbsp;<A href="http://blog.stalkr.net/" 
            target=_blank><B>StalkR's Blog</B></A></TD>
          <TD>&nbsp;<A href="http://www.corelan.be:8800/" 
            target=_blank><B>Peter Van Eeckhoutte's Blog</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://shell-unix.ath.cx/"><B>DNS 2</B></A></TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://www.shatter-blog.net/" 
            target=_blank><B>Shatter-blog</B></A></TD>
          <TD>&nbsp;<A href="http://blog.nibbles.fr/" target=_blank><B>Nibbles 
            microblog</B></A></TD>
          <TD>&nbsp;<A href="http://www.ghostsinthestack.org/" 
            target=_blank><B>Ghosts In The Stack</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://shellcode.homelinux.org/"><B>DNS 
          3</B></A></TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://blog.w4kfu.com/" target=_blank><B>W4kfu's 
            bl0g</B></A></TD>
          <TD>&nbsp;<A href="http://0vercl0k.blogspot.com/" 
            target=_blank><B>0vercl0k's blog</B></A></TD>
          <TD>&nbsp;<A href="http://www.ivanlef0u.tuxfamily.org/" 
            target=_blank><B>Ivanlef0u's blog</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://sources-codes.homelinux.org/"><B>DNS 
            4</B></A></TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://falken.tuxfamily.org/" 
            target=_blank><B>falken's blog</B></A></TD>
          <TD>&nbsp;<A href="http://mysterie.fr/blog/index.php" 
            target=_blank><B>Mysterie's blog</B></A></TD>
          <TD>&nbsp;<A href="http://sh4ka.fr/" target=_blank><B>Sh4ka's 
            Blog</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://assembly.homelinux.org/"><B>DNS 
          5</B></A></TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://www.root-me.org/" 
            target=_blank><B>Root-Me</B></A></TD>
          <TD>&nbsp;<A href="http://binholic.blogspot.com/" 
            target=_blank><B>m_101's blog</B></A></TD>
          <TD>&nbsp;<A href="http://plasticsouptaste.blogspot.com/" 
            target=_blank><B>Sm0k's blog</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD></TD></TR>
        <TR>
          <TD height=1>&nbsp;</TD></TR></TBODY></TABLE></TD></TR>
  <TR>
    <TD bgColor=#cccccc height=1></TD></TR>
  <TR>
    <TD bgColor=#3b3b3b height=3></TD></TR>
  <TR>
    <TD bgColor=#3b3b3b align=right><FONT color=#ffffff size=1><B>Shell-Storm 
      Network - 2011-2011 &nbsp;&nbsp;</B></FONT> </TD></TR>
  <TR>
    <TD bgColor=#3b3b3b height=3></TD></TR></TBODY></TABLE>
</BODY></HTML>