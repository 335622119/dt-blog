<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<!-- saved from url=(0031)index.php -->
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>0x255.com | 自由平等的漏洞报告平台</TITLE>
<META content="text/html; charset=utf-8" http-equiv=Content-Type>
<META name=author content=80sec>
<META name=copyright content=>
<META name=keywords content=,0x255,应用安全,web安全,系统安全,网络安全,漏洞公布,漏洞报告,安全资讯。>
<META name=description content=0x255是一个位于厂商和安全研究者之间的漏洞报告平台,注重尊重,进步,与意义><LINK 
title="wooyun.org 最新提交漏洞" rel=alternate type=application/rss+xml 
href=" feeds/submit"><LINK title="0x255.com 最新确认漏洞" 
rel=alternate type=application/rss+xml 
href=" feeds/confirm"><LINK title="0x255.com 最新公开漏洞" 
rel=alternate type=application/rss+xml 
href=" feeds/public"><LINK rel=stylesheet type=text/css 
href="__PUBLIC__/blog/css/style.css">
<SCRIPT type=text/javascript 
src="__PUBLIC__/blog/js/jquery-1.4.2.min.js"></SCRIPT>
<style>
.footerstyle TD A{color:#AB8D13}
.footerstyle TD A:visited {COLOR: #white; TEXT-DECORATION: none}
.footerstyle TD A:hover {COLOR: #white;}

</style>

<META name=GENERATOR content="MSHTML 8.00.6001.19046"></HEAD>
<BODY>
<DIV class=banner>
<TABLE border=0 cellSpacing=0 cellPadding=0 width="100%" bgColor=#ffffff 
align=center height=189>
  <TBODY>
  <TR>
    <TD height=5 background=__PUBLIC__/blog/images/bg4.jpg></TD></TR>
 
    <TD>
      <TABLE border=0 cellSpacing=0 cellPadding=0 width="100%" height=189>
        <TBODY>
        <TR>
          <TD height=189 background=__PUBLIC__/blog/images/globe.gif rowSpan=3 width=181 
          noWrap>&nbsp;</TD>
          <TD bgColor=#ffffff height=72 colSpan=2 noWrap>&nbsp;</TD>
          <TD bgColor=#ffffff height=72></TD></TR>
        <TR>
          <TD bgColor=#ffffff height=69 width=23 noWrap>&nbsp;</TD>
          <TD height=69><A href="http://www.0x255.com/"><IMG border=0 
            src="__PUBLIC__/blog/images/shell-storm.gif" height=69></A></TD>
          <TD bgColor=#ffffff height=69 align=right>&nbsp; <A 
            href="http://twitter.com/shell_storm"></A> </TD></TR>
        <TR>
          <TD height=48 background=__PUBLIC__/blog/images/milieu.gif width=23 
          noWrap>&nbsp;</TD>
          <TD height=48 background=__PUBLIC__/blog/images/milieu.gif colSpan=2 noWrap 
          align=left>&nbsp; <B><A href="__ROOT__/index" 
            target=_self>首页</A> |</B> <B><A 
            href="__ROOT__/Corps" target=_self>厂商列表</A> 
            |</B> <B><A href="__ROOT__/Whitehats" 
            target=_self>白帽子</A> |</B> <B><A 
            href="__ROOT__/bugs" target=_self>漏洞列表</A> 
            |</B> <B><A href="__ROOT__/bugsub" 
            target=_self>提交漏洞</A> |</B>   | 
            <?php if(isset($_SESSION['username'])): ?><B>&nbsp;&nbsp;欢迎<A 
            href="__ROOT__/Member/memberinfo" target=_self><?php echo ($_SESSION['username']); ?></A>白帽 <a href="__ROOT__/Member">控制面板</a>| <a href="__ROOT__/Member/loginout" class="reg">退出</a>  |</B> 
            <?php else: ?>
            <B><A 
            href="__ROOT__/Whitehats/userlogin" target=_self>白帽登陆</A> |</B>
           
            |<B><?php endif; ?>
                       <?php if(isset($_SESSION['corps_id'])): ?><B>&nbsp;&nbsp;欢迎<A 
            href="__ROOT__/Managecorps/corpsinfo" target=_self><?php echo ($_SESSION['exp_corpser']); ?></A>厂商<a href="__ROOT__/Managecorps">控制面板</a>| <a href="__ROOT__/Managecorps/loginout" class="reg">退出</a>  |</B> 
            <?php else: ?>
            <B><A 
            href="__ROOT__/Corps/corpslogin" target=_self>厂商登陆</A> |</B><?php endif; ?>

              </TD></TR></TBODY></TABLE>

	<div class="bread">
		<div style="float:left">当前位置：<a href="/index.php">WooYun</a> >> <a href="">漏洞提交</a></div>
			</div>
	<link href="__PUBLIC__/blog/js/editor/editor.css" rel="stylesheet" type="text/css"/>
	<script src="__PUBLIC__/blog/js/editor.js" type="text/javascript"></script>

	<div class="content">

		<p class="whiteHatCaption caption">你可以提交关于厂商的各种漏洞，不局限于传统意义上的产品漏洞，包括网络配置，服务器管理，钓鱼欺诈甚至是有证据的黑客事件都可以作为有效的信息提交</p>

		<Form action="bugsub/addexp" method="POST" onsubmit="return checkBlank();">

			<table class="formTable">
				<tr>
					<th width="120">验证码：</th>
					<td>
						<input type="text" id="captcha" onblur="checkCaptcha(this.value)"  name="captcha" style="width:80px" />&nbsp;<img onclick="this.src='bugsub/verify?'+Math.random()" style="width:65px;height:18px;cursor:pointer" src="bugsub/verify" />
						</span> <span id="captcha_error" class="error"></span>
					</td>			
				</tr>
								<tr>
				<th width="120">是否获取邀请码：</th>
					<td>
						<input type="radio" name="invite" id="invite" checked="checked" onclick="document.getElementById('email').value='';document.getElementById('invite_email').style.display = 'none';" value="0"/>
						<label for="invite">否</label>
						<input type="radio" name="invite" onclick="document.getElementById('invite_email').style.display = '';" value="1"/>
						<label for="invite">是</label>
					</td>
				</tr>
								<tr id="invite_email" style="display: none;">
					<th width="120">邮箱：</th>
					<td>
						<input type="text" id="email" name="email">
					</td>			
				</tr>
				<tr>
					<th width="120">问题厂商类型：</th>
					<td>
						<input type="radio" name="corptype" id="netCorp" checked="checked" value="1"/>
						<label for="netCorp">互联网厂商</label>
						<input type="radio" name="corptype" id="tradition" value="2"/>
						<label for="tradition">传统应用</label>
						<span id="corptype_remark" class="remark"></span>
					</td>
				</tr>
				<tr>
					<th>问题厂商：</th>
					<td>
						<select name="corpid" id="corpid"><option value='-1' selected="selected">--选择问题厂商--</option></select> 
						<input type="text" name="corpname" id="corpname" style="display: none;" /><span id="corpid_remark" class="remark"></span> <span id="corpid_error" class="error"></span>
					</td>
				</tr>
				<tr>
					<th>漏洞类型：</th>
					<td>
						<select name="bugtype" id="bugtype_level1">
						</select>
						<input type="text" style="display: none; width: 150px;" name="other_bugtype" id="other_bugtype" />
						<select name="bug_subtype" id="bugtype_level2">
						</select><span id="bugtype_remark" class="remark"></span>
					</td>
				</tr>

				<tr>
					<th>漏洞标题：</th>
					<td><input type="text" name="bugtitle" size="50" id="bugtitle"/><span id="bugtitle_remark" class="remark"></span> <span id="bugtitle_error" class="error"></span></td>
				</tr>
				<tr>
					<th>漏洞等级：</th>
					<td>
						<select name="harmlevel" id="harmlevel"/>
							<option selected="selected" value=''>--选择漏洞等级--</option>
							<option value="1">低</option>
							<option value="2">中</option>
							<option value="3">高</option>
						</select><span id="harmlevel_remark" class="remark"></span> <span id="harmlevel_error" class="error"></span>
					</td>
				</tr>
				<tr>
					<th>自评Rank：</th>
					<td><input type="text" name="whitehat_rank" size="15" id="whitehat_rank"/><span id="whitehat_rank_remark" class="remark"></span> <span id="whitehat_rank_error" class="error"></span></td>
				</tr>
				<tr>
					<th valign="top">问题描述：</th>
					<td><textarea rows="4" cols="70" name="description"></textarea><br/><span id="description_remark" class="remark"></span></td>
				</tr>
				
				<tr>
					<th valign="top">详细说明：</th>
					<td><div class="editor">
						<div id="editor_tools" class="tools"></div>
						<textarea rows="4" cols="70" id="editor_content" name="content"></textarea>
					</div>
					<span id="content_remark" class="remark"></span></td>	
				</tr>
				<tr>
					<th valign="top">漏洞证明：</th>
					<td><div class="editor">
						<div id="editor_tools1" class="tools"></div>
						<textarea rows="4" cols="70" id="editor_content1" name="poc"></textarea>
					</div>
					<span id="poc_remark" class="remark"></span></td>
				</tr>
				<tr>
					<th valign="top">漏洞修复：</th>
					<td><div class="editor">
						<div id="editor_tools2" class="tools"></div>
						<textarea rows="4" cols="70" id="editor_content2" name="patch"></textarea>
					</div>
					<span id="patch_remark" class="remark"></span></td>
				</tr>

				<tr>
					<th>&nbsp;</th>
					<td><input type="submit" value="提交"/></td>
				</tr>
			</table>

		</FORM>
		<script type="text/javascript" src="__PUBLIC__/blog/js/common.js"></script>
<script type="text/javascript">


WooyunEditor("editor_content","editor_tools",[]);
WooyunEditor("editor_content1","editor_tools1",[]);
WooyunEditor("editor_content2","editor_tools2",[]);
var URL = '__URL__'; 
var APP  =  '__APP__'; 
var PUBLIC = '__PUBLIC__'; 
var Public = '../Public/'; 
var SELF = '__SELF__'; 
(function() {
	loadCorpOptions("Bugsub/getcorpname", document.getElementById("corpid"), function(select) {
		if (select.options.length == 1) {
			document.getElementById("corpname").style.display = "inline";
		}
	});
	$("#corpid").change(function() {
		var select = document.getElementById("corpid");
		if (parseInt(select.options[select.selectedIndex].value) == 0) {
			document.getElementById("corpname").style.display = "inline";
		} else {
			document.getElementById("corpname").style.display = "none";
		}
	});

	var level0 = 1;
	var level1 = 1;
	
	function showOther() {
		document.getElementById("other_bugtype").style.display = "inline";
		document.getElementById("bugtype_level2").style.display = "none";
	}
	
	function hideOther() {
		document.getElementById("other_bugtype").style.display = "none";
		document.getElementById("bugtype_level2").style.display = "inline";
	}	

	$("#netCorp").click(function() {
		level0 = 1;
		loadLevel1();
		hideOther();
	});
	
	$("#tradition").click(function() {
		level0 = 2;
		loadLevel1();	
		hideOther();
	});
	
	var loadLevel1 = function() {
		loadOptions("Bugsub/getExp/id/"+level0, document.getElementById("bugtype_level1"), function(typeid) {
			level1 = typeid;
			var option = document.createElement("option");
			document.getElementById("bugtype_level1").options.add(option);
			option.value = "0";
			option.innerHTML = "other";
			loadLevel2();
		});
	}
	
	var loadLevel2 = function() {
		loadOptions("Bugsub/getCExp/id/"+level1, document.getElementById("bugtype_level2"));
	}
	
	loadLevel1();
	
	$("#bugtype_level1").change(function() {
		var select = document.getElementById("bugtype_level1");
		
		if (parseInt(select.options[select.selectedIndex].value) == 0) {
			showOther();
			return;
		} else {
			hideOther();
		}
		
		level1 = parseInt(select.options[select.selectedIndex].value);			
		loadLevel2();
	});
})();

initForm({
		"corptype" : "该漏洞对应厂商的类型",
		"corpid" : "该漏洞对应厂商的名称",
		"bugtype" : "该漏洞的类型，乱选扣分",
		"bugtitle" : "该漏洞的标题",
		"harmlevel" : "该漏洞的危害等级",
		"description" : "对漏洞的简要描述，可以简单描述漏洞的危害和成因，不要透漏漏洞的细节",
		"content" : "对漏洞的详细描述，请尽量多的深入细节以方便对漏洞的理解",
		"poc" : "给出问题的概念性证明",
		"patch" : "建议的漏洞修复方案"
});

$('#harmlevel').change(function () {
	$("#whitehat_rank_remark").css("display","inline");
	if($("#harmlevel").val() == "1") {
	    $("#whitehat_rank_remark").html("对漏洞rank进行自评，漏洞等级为 低 时，自评Rank为0-5！");
	} else if($("#harmlevel").val() == "2") {
	    $("#whitehat_rank_remark").html("对漏洞rank进行自评，漏洞等级为 中 时，自评Rank为5-10！");
	} else if($("#harmlevel").val() == "3") {
	    $("#whitehat_rank_remark").html("对漏洞rank进行自评，漏洞等级为 高 时，自评Rank为10-20！");
	}
});
function checkBlank(){
	
	$(".remark,.error").empty();
	
	if($("#captcha").val() == ""){
		$("#captcha_error").html("请输入图片中的验证码！");
	}

	if($("#corpid").val() == "--选择问题厂商--"){
		$("#corpid_error").html("请选择问题厂商！");
	}

	if($("#bugtitle").val() == ""){
		$("#bugtitle_error").html("漏洞标题不能为空！");
	}

	if($("#harmlevel").val() == "--选择漏洞等级--"){
		$("#harmlevel_error").html("请选择漏洞等级！");
	} else if($("#harmlevel").val() == "1" && ($("#whitehat_rank").val() > 5 || $("#whitehat_rank").val()<0 ) ) {
		$("#whitehat_rank_error").html("漏洞等级为 低 时，自评Rank为0-5！");
		return false;
	} else if($("#harmlevel").val() == "2" && ($("#whitehat_rank").val() > 10 || $("#whitehat_rank").val()<5 ) ) {
		$("#whitehat_rank_error").html("漏洞等级为 中 时，自评Rank为5-10！");
		return false;
	} else if($("#harmlevel").val() == "3" &&($("#whitehat_rank").val() > 20 || $("#whitehat_rank").val()<10 ) ) {
		$("#whitehat_rank_error").html("漏洞等级为 高 时，自评Rank为10-20！");
		return false;
	}

	if($("#whitehat_rank").val() == ""){
		$("#whitehat_rank_error").html("请填写自评Rank！");
	}

	if($("#captcha").val() == "" || $("#corpid").val() == "--选择问题厂商--" || $("#bugtitle").val() == "" || $("#harmlevel").val() == "--选择漏洞等级--"){
		return false;
	}

}

function checkCaptcha(captcha){
	if(captcha==""){
		$("#captcha_error").html("请输入图片中的验证码！");
	}else{
		$.get("bugsub/checkcode",{"module":"checkcaptcha","captcha":captcha},function(data){
			if(parseInt(data)!=1){
				$("#captcha_error").html("验证码输入错误！");
			}else{
				$("#captcha_error").html("");
			}
		});
	}
}

</script>
	</div>
	<br/>
     <TABLE border=0 cellSpacing=0 cellPadding=0  width="100%" 
      background=__PUBLIC__/blog/images/bg4.jpg class="footerstyle">
        <TBODY>
        <TR>
          <TD>&nbsp;<FONT color=#ffffff size=2><B><U>Links 
          :</B></FONT></U><BR></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<FONT color=#ffffff size=2><B><U>Others DNS 
            :</B></FONT></U><BR></TD>
          <TD>&nbsp;</TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="#" target=_blank><B>Nuit 
            Du Hack</B></A></TD>
          <TD>&nbsp;<A href="http://www.sysdream.com/" 
            target=_blank><B>Sysdream</B></A></TD>
          <TD>&nbsp;<A href="http://www.zeroscience.mk/" 
            target=_blank><B>ZeroScience</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://opensource.homeunix.com/"><B>DNS 
          1</B></A></TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://www.acissi.net/" 
            target=_blank><B>Acissi</B></A></TD>
          <TD>&nbsp;<A href="http://blog.stalkr.net/" 
            target=_blank><B>StalkR's Blog</B></A></TD>
          <TD>&nbsp;<A href="http://www.corelan.be:8800/" 
            target=_blank><B>Peter Van Eeckhoutte's Blog</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://shell-unix.ath.cx/"><B>DNS 2</B></A></TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://www.shatter-blog.net/" 
            target=_blank><B>Shatter-blog</B></A></TD>
          <TD>&nbsp;<A href="http://blog.nibbles.fr/" target=_blank><B>Nibbles 
            microblog</B></A></TD>
          <TD>&nbsp;<A href="http://www.ghostsinthestack.org/" 
            target=_blank><B>Ghosts In The Stack</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://shellcode.homelinux.org/"><B>DNS 
          3</B></A></TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://blog.w4kfu.com/" target=_blank><B>W4kfu's 
            bl0g</B></A></TD>
          <TD>&nbsp;<A href="http://0vercl0k.blogspot.com/" 
            target=_blank><B>0vercl0k's blog</B></A></TD>
          <TD>&nbsp;<A href="http://www.ivanlef0u.tuxfamily.org/" 
            target=_blank><B>Ivanlef0u's blog</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://sources-codes.homelinux.org/"><B>DNS 
            4</B></A></TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://falken.tuxfamily.org/" 
            target=_blank><B>falken's blog</B></A></TD>
          <TD>&nbsp;<A href="http://mysterie.fr/blog/index.php" 
            target=_blank><B>Mysterie's blog</B></A></TD>
          <TD>&nbsp;<A href="http://sh4ka.fr/" target=_blank><B>Sh4ka's 
            Blog</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://assembly.homelinux.org/"><B>DNS 
          5</B></A></TD></TR>
        <TR>
          <TD>&nbsp;</TD>
          <TD>&nbsp;<A href="http://www.root-me.org/" 
            target=_blank><B>Root-Me</B></A></TD>
          <TD>&nbsp;<A href="http://binholic.blogspot.com/" 
            target=_blank><B>m_101's blog</B></A></TD>
          <TD>&nbsp;<A href="http://plasticsouptaste.blogspot.com/" 
            target=_blank><B>Sm0k's blog</B></A></TD>
          <TD>&nbsp;</TD>
          <TD>&nbsp;</TD>
          <TD></TD></TR>
        <TR>
          <TD height=1>&nbsp;</TD></TR></TBODY></TABLE></TD></TR>
  <TR>
    <TD bgColor=#cccccc height=1></TD></TR>
  <TR>
    <TD bgColor=#3b3b3b height=3></TD></TR>
  <TR>
    <TD bgColor=#3b3b3b align=right><FONT color=#ffffff size=1><B>Shell-Storm 
      Network - 2011-2011 &nbsp;&nbsp;</B></FONT> </TD></TR>
  <TR>
    <TD bgColor=#3b3b3b height=3></TD></TR></TBODY></TABLE>
</BODY></HTML>