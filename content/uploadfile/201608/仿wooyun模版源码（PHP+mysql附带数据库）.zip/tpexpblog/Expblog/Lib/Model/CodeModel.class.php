<?php
/*
 *邀请码的模型 
 */
class CodeModel extends Model{
	
}