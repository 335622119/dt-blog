<?php
return array (
  0 => 'corps_id',
  1 => 'exp_corpser',
  2 => 'exp_homepage',
  3 => 'exp_doing',
  4 => 'exp_addtime',
  5 => 'exp_corps_intro',
  '_autoinc' => true,
  '_pk' => 'corps_id',
);
?>