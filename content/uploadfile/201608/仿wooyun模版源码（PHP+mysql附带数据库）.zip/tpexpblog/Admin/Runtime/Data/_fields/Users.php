<?php
return array (
  0 => 'id',
  1 => 'exp_username',
  2 => 'exp_password',
  3 => 'exp_regtime',
  4 => 'exp_ip',
  5 => 'exp_status',
  6 => 'exp_homepage',
  7 => 'exp_useremail',
  8 => 'exp_userprofile',
  9 => 'exp_truename',
  10 => 'exp_mobile',
  11 => 'exp_telephone',
  12 => 'exp_useraddress',
  13 => 'exp_postalcode',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>