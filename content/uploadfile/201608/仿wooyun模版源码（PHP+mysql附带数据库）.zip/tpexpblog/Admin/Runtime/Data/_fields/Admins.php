<?php
return array (
  0 => 'id',
  1 => 'exp_username',
  2 => 'exp_password',
  3 => 'exp_status',
  4 => 'exp_email',
  5 => 'exp_regtime',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>