<?php
return array (
  0 => 'id',
  1 => 'exp_code',
  2 => 'exp_isused',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>