<?php
return array (
  0 => 'id',
  1 => 'posts_id',
  2 => 'user_id',
  3 => 'content',
  4 => 'addtime',
  '_autoinc' => true,
  '_pk' => 'id',
);
?>