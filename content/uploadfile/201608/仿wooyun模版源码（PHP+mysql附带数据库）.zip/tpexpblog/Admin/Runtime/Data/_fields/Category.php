<?php
return array (
  0 => 'exp_category_id',
  1 => 'exp_bugtype',
  2 => 'exp_category_fid',
  3 => 'exp_corptype',
  '_autoinc' => true,
  '_pk' => 'exp_category_id',
);
?>