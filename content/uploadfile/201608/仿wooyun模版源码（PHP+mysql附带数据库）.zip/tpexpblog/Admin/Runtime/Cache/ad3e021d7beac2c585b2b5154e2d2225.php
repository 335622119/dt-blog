<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<link rel="stylesheet" href="__PUBLIC__/admin/css/common.css" type="text/css" />
<title>管理区域</title>
</head>

<body>
<div id="man_zone">
  <table width="99%" border="0" align="center"  cellpadding="3" cellspacing="1" class="table_style">
    <tr>
      <td width="18%" class="left_title_1"><span class="left-title">您的级别</span></td>
      <td width="82%">&nbsp;大黑阔</td>
    </tr>
    <tr>
      <td class="left_title_2">PHP版本</td>
      <td>&nbsp;PHP<?php echo ($phpversion); ?></td>
    </tr>
    <tr>
      <td class="left_title_1">Apache版本</td>
      <td>&nbsp;<?php echo ($getapache); ?></td>
    </tr>
    <tr>
      <td class="left_title_2">GD库&nbsp;</td>
      <td>&nbsp;<?php echo ($gd); ?></td>
    </tr>
    <tr>
      <td class="left_title_1">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="left_title_2">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="left_title_1">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="left_title_2">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="left_title_1">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr bgcolor="#FFFFFF">
      <td class="left_title_2">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
  </table>
</div>
</body>
</html>