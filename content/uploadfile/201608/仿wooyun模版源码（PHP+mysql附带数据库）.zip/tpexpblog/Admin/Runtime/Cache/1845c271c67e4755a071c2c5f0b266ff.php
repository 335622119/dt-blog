<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3c.org/TR/1999/REC-html401-19991224/loose.dtd">
<!-- saved from url=(0031)index.php -->
<HTML xmlns="http://www.w3.org/1999/xhtml"><HEAD><TITLE>0x255.com | 自由平等的漏洞报告平台</TITLE>
<META content="text/html; charset=utf-8" http-equiv=Content-Type>
<META name=author content=80sec>
<META name=copyright content=>
<META name=keywords content=,0x255,应用安全,web安全,系统安全,网络安全,漏洞公布,漏洞报告,安全资讯。>
<META name=description content=0x255是一个位于厂商和安全研究者之间的漏洞报告平台,注重尊重,进步,与意义><LINK 
title="wooyun.org 最新提交漏洞" rel=alternate type=application/rss+xml 
href=" feeds/submit"><LINK title="0x255.com 最新确认漏洞" 
rel=alternate type=application/rss+xml 
href=" feeds/confirm"><LINK title="0x255.com 最新公开漏洞" 
rel=alternate type=application/rss+xml 
href=" feeds/public"><LINK rel=stylesheet type=text/css 
href="__PUBLIC__/blog/css/style.css">
<SCRIPT type=text/javascript 
src="__PUBLIC__/blog/js/jquery-1.4.2.min.js"></SCRIPT>
<style>
.footerstyle TD A{color:#AB8D13}
.footerstyle TD A:visited {COLOR: #white; TEXT-DECORATION: none}
.footerstyle TD A:hover {COLOR: #white;}

</style>

<META name=GENERATOR content="MSHTML 8.00.6001.19046"></HEAD>
<BODY>
<DIV class=banner>
<TABLE border=0 cellSpacing=0 cellPadding=0 width="100%" bgColor=#ffffff 
align=center height=189>
  <TBODY>
  <TR>
    <TD height=5 background=__PUBLIC__/blog/images/bg4.jpg></TD></TR>
 
    <TD>


	<div class="bread">
	


	<div class="content">

		<h2>漏洞概要 </h2>
		
		<h3>缺陷编号：		Exploit-<?php echo ($list['exp_post_no']); ?></h3>

		<h3>漏洞标题：		<?php echo ($list['exp_post_title']); ?>  </h3>

		<h3>相关厂商：		<?php echo ($list['exp_corpser']); ?><?php echo ($list['other_corpname']); ?></h3>

		<h3>漏洞作者：		<?php echo ($list['exp_username']); ?></h3>

		<h3>提交时间：		<?php echo ($list['exp_post_time']); ?></h3>
				<h3>漏洞类型：		
					
				 <?php echo ($list['other_bugtype']); ?>
				 <?php echo ($list['exp_bugtype']); ?>
			

				</h3>
		
		<h3>危害等级：		<?php echo ($exp_hazard_rating); ?></h3>
		
		<h3>自评Rank：		<?php echo ($list['exp_exploit_rank']); ?></h3>

		<h3>漏洞状态：		<?php echo ($exp_exploit_status); ?></h3>

		<h3>漏洞来源：		<?php echo ($list['exp_exploit_from']); ?></h3>
	
		<hr align="center"/>

		<h2>漏洞详情</h2>
		
<h3 class="detailTitle">简要描述：</h3>

		<p class="detail"><?php echo ($list['exp_description']); ?></p>
					
						<h3 class="detailTitle">详细说明：</h3>
		
			<p class="detail"><?php echo ($list['exp_content']); ?></p>
				
									<h3 class="detailTitle">漏洞证明：</h3>

			<p class="detail"><?php echo ($list['exp_content1']); ?></p>

									<h3 class="detailTitle">修复方案：</h3>
			<p class="detail"><?php echo ($list['exp_exploit_fix']); ?></p>
			
			
		
		<hr align="center"/>

				
			<h2>漏洞回应</h2>
			
			
									<h3 class="detailTitle">厂商回应：</h3>
					
					<p class="detail"><?php echo ($replay); ?></p>
							
					

		

<hr align="center" />
<h2>评论</h2>
<div class="comment">
<dl class="commentlist">
<?php if(is_array($msgs)): $i = 0; $__LIST__ = $msgs;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): ++$i;$mod = ($i % 2 )?><dt>
		<?php echo ($vo['addtime']); ?><span class="user"><?php echo ($vo['exp_username']); ?></span>
</dt>
	<dd><?php echo ($vo['content']); ?></dd><?php endforeach; endif; else: echo "" ;endif; ?>
</dl>
</div>
<div class="reply">
<?php if(isset($_SESSION['username'])): ?><FORM action="__ROOT__/bugs/leavemsg" method="post" onsubmit="return CheckComment()">
<p class="detail">
<input type="hidden" id="postid" name="postid" value="<?php echo ($list['id']); ?>" />
<textarea rows="4" cols="60" id="comment_content" name="comment_content" onclick="if(this.value=='点击输入评论内容') this.value=''">点击输入评论内容</textarea></p>
<p class="detail">
验证码 <input type="text" id="captcha" name="captcha" style="width:80px" />&nbsp;<img onclick="this.src='__ROOT__/bugs/verify?'+Math.random()" style="width:65px;height:18px;cursor:pointer" src="__ROOT__/bugs/verify" align="absmiddle" />
&nbsp;&nbsp;<input type="submit" value="发表评论"/>
</p>
</FORM>
<script type="text/javascript"> 
 
function CheckComment(){
	if($("#comment_content").val()=="" || $("#comment_content").val()=="点击输入评论内容"){
		alert("请输入评论内容！");
		return false;
	}
	if($("#captcha").val()==""){
		alert("请输入验证码！");
		return false;
	}
}
</script>

<?php else: ?>
<p class="detail">
登录后才能发表评论，请先 <a href="__ROOT__/Whitehats/userlogin"><u>登录</u></a> 。
</p><?php endif; ?>
<div>
	</div>

</HTML>