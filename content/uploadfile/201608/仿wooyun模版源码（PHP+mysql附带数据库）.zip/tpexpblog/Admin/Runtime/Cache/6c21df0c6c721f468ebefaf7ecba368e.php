<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<link rel="stylesheet" href="__PUBLIC__/admin/css/common.css" type="text/css" />
<title>厂商管理</title>
 <script src="__PUBLIC__/admin/js/jquery.js" type="text/javascript"></script>

</head>

<body>
<div id="man_zone">
  <table width="99%" border="0" align="center"  cellpadding="3" cellspacing="1" class="table_style">

    <tr>
     <td>厂商ID</td>
      <td>厂商名</td>
   	 <td>厂商主页</td>
   	 <td>厂商添加时间</td>
   	 <td>系统操作</td>
    </tr>
    <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): ++$i;$mod = ($i % 2 )?><tr>
      <td><?php echo ($vo['corps_id']); ?></td>
      <td>&nbsp;<?php echo ($vo['exp_corpser']); ?></td>
       <td>&nbsp;<?php echo ($vo['exp_homepage']); ?></td>
        <td>&nbsp;<?php echo ($vo['exp_addtime']); ?></td>
        <td>&nbsp;<a href="modifycorps/id/<?php echo ($vo['corps_id']); ?>">修改</a>&nbsp;/&nbsp;<a href="delcorps/id/<?php echo ($vo['corps_id']); ?>" onclick="return confirm('确定要删除选择的信息吗？此操作不可以恢复！')" >删除</a></td>
    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
  </table>
</div>
</body>
</html>