<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<link rel="stylesheet" href="__PUBLIC__/admin/css/common.css" type="text/css" />
<title>添加厂商</title>
 <script src="__PUBLIC__/admin/js/jquery.js" type="text/javascript"></script>
<script>
	function checkf(){
		if($("#corpser").val()==''){
			$("#tips1").html("请填写厂商名");
			alert("请填写厂商名");
			return false;
		}
			if($("#homepage").val()==''){
					$("#tips2").html("请填写厂商主页");
					alert("请填写厂商主页");
					return false;
				}
			return true;
		}
</script>
</head>

<body>
<div id="man_zone">
  <table width="99%" border="0" align="center"  cellpadding="3" cellspacing="1" class="table_style">
   <FORM method="post"  action="Corps/addcorps" >
    <tr>
      <td width="18%" class="left_title_1"><span class="left-title">厂商名</span></td>
      <td width="82%">&nbsp;<input type="text" name="corpser" id="corpser" />&nbsp;<span style="color:red" name="tips1" id="tips1"></span></td>
    </tr>
    
    <tr>
      <td class="left_title_2">厂商主页</td>
      <td>&nbsp;<input type="text" name="homepage" id="homepage" />&nbsp;<span style="color:red" name="tips2" id="tips2"></span> </td>
    </tr>
    <tr>
      <td class="left_title_1">厂商介绍</td>
      <td>&nbsp;<textarea rows="6" cols="70" id="corps_intro" name="corps_intro"></textarea></td>
    </tr>
    <tr>
      <td class="left_title_2"></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="left_title_1">&nbsp;</td>
      <td>&nbsp;<input type="submit" name="sub" value="提交" />&nbsp;&nbsp;&nbsp;<input type="reset" value="重置"/></td>
    </tr>
    <tr>
      <td class="left_title_2">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="left_title_1">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="left_title_2">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="left_title_1">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr bgcolor="#FFFFFF">
      <td class="left_title_2">&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    </FORM>
  </table>
</div>
</body>
</html>