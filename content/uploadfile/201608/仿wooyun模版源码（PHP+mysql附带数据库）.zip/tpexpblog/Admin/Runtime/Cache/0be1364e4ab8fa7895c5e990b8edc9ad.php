<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<link rel="stylesheet" href="__PUBLIC__/admin/css/common.css" type="text/css" />
<title>漏洞分类管理</title>
 <script src="__PUBLIC__/admin/js/jquery.js" type="text/javascript"></script>

</head>

<body>
<div id="man_zone">
<input type="button" value="添加根分类" onclick="window.location.href='__URL__/exploitype/id/0/corptype/1'" />
  <table width="99%" border="0" align="center"  cellpadding="3" cellspacing="1" class="table_style">

    <tr>
     <td>ID</td>
      <td>问题厂商类型</td>
      <td>所属分类</td>

   	 <td>系统操作</td>
    </tr>
    <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): ++$i;$mod = ($i % 2 )?><tr>
      <td><?php echo ($vo['exp_category_id']); ?></td>
      <td>&nbsp;
           <?php switch($vo["exp_corptype"]): ?><?php case "1":  ?>互联网厂商<?php break;?>
		
		<?php case "2":  ?>传统应用厂商<?php break;?>
		
		<?php default: ?><?php endswitch;?>

		
      </td>
      <td><a href="showexpcate/id/<?php echo ($vo['exp_category_id']); ?>"><?php echo ($vo['exp_bugtype']); ?></a></td>

        <td><a href="__URL__/exploitype/id/<?php echo ($vo['exp_category_id']); ?>/corptype/<?php echo ($vo['exp_corptype']); ?>">添加子类</a>/&nbsp;<a href="__URL__/modifycate/id/<?php echo ($vo['exp_category_id']); ?>">修改</a>&nbsp;/&nbsp;<a href="__URL__/delcate/id/<?php echo ($vo['exp_category_id']); ?>" onclick="return confirm('确定要删除选择的信息吗？此操作不可以恢复！')" >删除</a></td>
    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
  </table>
</div>
</body>
</html>