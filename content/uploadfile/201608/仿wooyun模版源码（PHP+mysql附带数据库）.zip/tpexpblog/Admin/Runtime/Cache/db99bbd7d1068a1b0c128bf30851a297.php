<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<link rel="stylesheet" href="__PUBLIC__/admin/css/common.css" type="text/css" />
<title>编辑类型</title>
 <script src="__PUBLIC__/admin/js/jquery.js" type="text/javascript"></script>

</head>

<body>
<div id="man_zone">
  <input type="button" value="返回" onclick="javascript:history.back()" />
  <table width="99%" border="0" align="center"  cellpadding="3" cellspacing="1" class="table_style">
   <FORM method="post" id="Exploit/exploitype" name="corps" action="__URL__/exploitype/">
    <tr>
      <td width="18%" class="left_title_1"><span class="left-title">问题厂商类型:</span></td>
      <td width="82%">&nbsp;<input type="radio" name="corptype" id="netCorp" value="1"  <?php if(($data["corpsid"])  ==  "1"): ?>checked=true"<?php endif; ?>/>
						<label for="netCorp">互联网厂商</label>
						<input type="radio" name="corptype" id="tradition" value="2" <?php if(($data["corpsid"])  ==  "2"): ?>checked=true<?php endif; ?>/>
						<label for="tradition">传统应用</label>
&nbsp;<span style="color:red" name="tips1" id="tips1"></span></td>
    </tr>
    
   
    <tr>
      <td class="left_title_1">漏洞类型:</td>
      <td>&nbsp;<input type="text" name="bugtype" id="bugtype" /><input type="hidden" name="bugtype_id" value=<?php echo ($id); ?> /></td>
    </tr>
    <tr>
      <td class="left_title_2"></td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td class="left_title_1">&nbsp;</td>
      <td>&nbsp;<input type="submit" name="sub" value="提交" />&nbsp;&nbsp;&nbsp;<input type="reset" value="重置"/></td>
    </tr>
   <tr>
   	
   </tr>
    </FORM>
  </table>
</div>
</body>
</html>