<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312" />
<link rel="stylesheet" href="__PUBLIC__/admin/css/common.css" type="text/css" />
<title>通用后台管理系统</title>
</head>

<body>
<div class="header_content">
     <div class="logo"><img src="__PUBLIC__/admin/images/man_logo.jpg" alt="" /></div>
	 <div class="right_nav">
	    <div class="text_left"><ul class="nav_list"></ul>
	    </div>
		<div class="text_right"><ul class="nav_return"><li><img src="__PUBLIC__/admin/images/return.gif" width="13" height="21" />&nbsp; [ <a href="#"></a> |  <a href="#"></a> ]</li>
		<li> [<a href="#"></a>]</li>
		<li> [<a href="#"></a>]&nbsp;&nbsp;</li>
		</ul>
		</div>
	 </div>
</div>
</body>
</html>