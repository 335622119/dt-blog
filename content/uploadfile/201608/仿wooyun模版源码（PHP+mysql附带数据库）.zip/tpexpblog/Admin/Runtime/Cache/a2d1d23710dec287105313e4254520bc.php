<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<link rel="stylesheet" href="__PUBLIC__/admin/css/common.css" type="text/css" />
<title>漏洞编辑修改查看</title>
 <script src="__PUBLIC__/admin/js/jquery.js" type="text/javascript"></script>

</head>

<body>
<div id="man_zone">
  <table width="99%" border="0" align="center"  cellpadding="3" cellspacing="1" class="table_style">
   <FORM method="post" id="member" name="member" action="__URL__/modifysave">
    <tr>
      <td width="18%" class="left_title_1"><span class="left-title">缺陷编号:</span></td>
      <td width="10%">&nbsp;<input type="text" name="exp_post_no" id="exp_post_no" value="<?php echo ($list['exp_post_no']); ?>" /></td>
      <td width="10%" class="left_title_1" >漏洞标题</td>
      <td><input type="text" name="bugtitle" id="bugtitle" value="<?php echo ($list['exp_post_title']); ?>" /></td>
    </tr>
    
    <tr>
      <td class="left_title_2">漏洞作者</td>
      <td>&nbsp; <select name="author_id">
      	<?php if(is_array($users)): $i = 0; $__LIST__ = $users;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$u): ++$i;$mod = ($i % 2 )?><option value="<?php echo ($u["id"]); ?>"  <?php if(($list["exp_author_id"])  ==  $u["id"]): ?>selected="selected"<?php endif; ?>><?php echo ($u['exp_username']); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
      </select>
      </td>
         <td class="left_title_2">是否公开</td>
      <td>&nbsp;
     	  <select name="exp_ispub">
    		<option value="0" <?php if(($list["exp_ispub"])  ==  "0"): ?>selected="selected"<?php endif; ?>>公开</option>
    		<option value="1" <?php if(($list["exp_ispub"])  ==  "1"): ?>selected="selected"<?php endif; ?>>不公开</option>
    	</select>
      </td>
    </tr>
        <tr>
  	  <td class="left_title_1">提交时间:</td>
      <td>&nbsp;<input type="text" name="posttime" id="posttime" value="<?php echo ($list['exp_post_time']); ?>" /></td>
      <td class="left_title_1">邀请码邮箱</td>
      <td><?php echo ($list['exp_email']); ?></td>
    </tr>
    <tr>
    	<td class="left_title_2">危害等级:</td>
    	<td>
    	<select name="exp_hazard_rating">
    		<option value="3" <?php if(($list["exp_hazard_rating"])  ==  "3"): ?>selected="selected"<?php endif; ?>>高</option>
    		<option value="2" <?php if(($list["exp_hazard_rating"])  ==  "2"): ?>selected="selected"<?php endif; ?>>中</option>
    		<option value="1" <?php if(($list["exp_hazard_rating"])  ==  "1"): ?>selected="selected"<?php endif; ?>>低</option>
    	</select>
    	</td>
    	<td class="left_title_1">自评Rank:</td>
    	<td><input type="text" name="exp_exploit_rank" id="exp_exploit_rank" value="<?php echo ($list['exp_exploit_rank']); ?>" /></td>
    </tr>
    <tr>
      <td class="left_title_2">漏洞状态</td>
      
      <td>&nbsp;
     <select name="exp_exploit_status">
     	<option value="0" <?php if(($list["exp_exploit_status"])  ==  "0"): ?>selected="selected"<?php endif; ?>>正在联系厂商或者等待认领</option>
     	<option value="1" <?php if(($list["exp_exploit_status"])  ==  "1"): ?>selected="selected"<?php endif; ?>>等待厂商处理</option>
     	<option value="2" <?php if(($list["exp_exploit_status"])  ==  "2"): ?>selected="selected"<?php endif; ?>>未联系到厂商或者厂商积极忽略</option>
     	<option value="3" <?php if(($list["exp_exploit_status"])  ==  "3"): ?>selected="selected"<?php endif; ?>>厂商已经确认</option>
     	<option value="4" <?php if(($list["exp_exploit_status"])  ==  "4"): ?>selected="selected"<?php endif; ?>>漏洞已经通知厂商但是厂商忽略漏洞</option>
     </select>
     </td>
       <td class="left_title_2"></td>
    	<td>

    	</td>
    </tr>
        <tr>
      <td class="left_title_2">问题描述：</td>
      <td>&nbsp;<textarea cols="20" rows="8" name="description"><?php echo ($list['exp_description']); ?></textarea></td>
       <td class="left_title_2">详细说明</td>
    	<td><textarea cols="20" rows="8" name="editor_content"><?php echo ($list['exp_content']); ?></textarea></td>
    </tr>
       <tr>
      <td class="left_title_2">漏洞证明：</td>
      <td>&nbsp;<textarea cols="20" rows="8" name="editor_content1"><?php echo ($list['exp_content1']); ?></textarea></td>
       <td class="left_title_2">漏洞修复</td>
    	<td><textarea cols="20" rows="8" name="editor_content2"><?php echo ($list['exp_exploit_fix']); ?></textarea></td>
    </tr>
    <tr>
      <td class="left_title_1">&nbsp;</td>
      <td>&nbsp;<input type="hidden" name="id" value="<?php echo ($list['id']); ?>" /><input type="submit" name="sub" value="提交" />&nbsp;&nbsp;&nbsp;<input type="button" onclick="javascript:history.back(-1);" value="返回"/></td>
        	<td></td>
    	<td></td>
    </tr>
    </FORM>
  </table>
</div>
</body>
</html>