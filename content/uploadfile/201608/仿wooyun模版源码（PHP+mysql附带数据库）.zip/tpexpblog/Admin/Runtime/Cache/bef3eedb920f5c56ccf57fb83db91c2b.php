<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<link rel="stylesheet" href="__PUBLIC__/admin/css/common.css" type="text/css" />
<title>会员管理</title>
 <script src="__PUBLIC__/admin/js/jquery.js" type="text/javascript"></script>

</head>

<body>
<div id="man_zone">
  <table width="99%" border="0" align="center"  cellpadding="3" cellspacing="1" class="table_style">

    <tr>
     <td>ID</td>
      <td>注册时间</td>
      <td>会员名</td>
   	 <td>会员邮箱</td>
   	 <td>当前状态</td>
   	 <td>系统操作</td>
   	
    </tr>
    <?php if(is_array($list)): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): ++$i;$mod = ($i % 2 )?><tr>
      <td><?php echo ($vo['id']); ?></td>
      <td>&nbsp;<?php echo ($vo['exp_regtime']); ?></td>
      <td><?php echo ($vo['exp_username']); ?></td>
      <td><?php echo ($vo['exp_useremail']); ?></td>
        <td>&nbsp;
        <?php switch($vo["exp_status"]): ?><?php case "0":  ?>账号已锁定<?php break;?>
			
			<?php case "1":  ?>账号需审核<?php break;?>
			
			<?php case "2":  ?>正常<?php break;?>
			<?php default: ?><?php endswitch;?>

        </td>
        <td>&nbsp;<a href="Member/modify/id/<?php echo ($vo['id']); ?>">修改</a>&nbsp;/&nbsp;<a href="delcorps/id/<?php echo ($vo['id']); ?>" onclick="return confirm('确定要删除选择的信息吗？此操作不可以恢复！')" >删除</a></td>
    </tr><?php endforeach; endif; else: echo "" ;endif; ?>
  </table>
  <div align="center"><?php echo ($page); ?></div>
</div>
</body>
</html>