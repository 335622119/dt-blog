<?php
/*
 * 邀请码模型类
 */
class CodeModel extends Model{

}