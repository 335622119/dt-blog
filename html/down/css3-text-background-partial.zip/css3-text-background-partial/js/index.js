/*@font-face {
  font-family: 'Scratch Decor';
  src: url('data:application/x-font-otf;charset=utf-8;base64,') format('eot'), 		
    url('data:application/x-font-ttf;charset=utf-8;base64,') format('truetype');
    } */