A Pen created at CodePen.io. You can find this one at http://codepen.io/thiesbrake/pen/zuhKC.

 A quick SVG graph which is animated via CSS3 animation. The coordinates are done with the CSS counter property. The counter is counting backwards, quite cool.